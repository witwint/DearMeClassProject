package classproject.dearme;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DearmeApplicationTests {

	@Test
	void contextLoads() {
	}

}
